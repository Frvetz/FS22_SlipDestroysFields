-- Contact: SlipDestroysFields@web.de
-- Date 13.08.2022

loadSettingsForClientEvent = {}
local loadSettingsForClientEvent_mt = Class(loadSettingsForClientEvent, Event)
InitEventClass(loadSettingsForClientEvent, "loadSettingsForClientEvent")

function loadSettingsForClientEvent.emptyNew()
	local event = Event.new(loadSettingsForClientEvent_mt)
	


	return event
end

function loadSettingsForClientEvent.new(Strength, StrengthState, DebugState)
    local event = loadSettingsForClientEvent.emptyNew()
	    event.Strength = Strength
        event.StrengthState = StrengthState
        event.DebugState = DebugState
	return event
end

function loadSettingsForClientEvent:readStream(streamId, connection)
    self.Strength = streamReadFloat32(streamId)
    self.StrengthState = streamReadInt32(streamId)
    self.DebugState = streamReadInt32(streamId)
	
	self:run(connection)
end

function loadSettingsForClientEvent:writeStream(streamId, connection)
	streamWriteFloat32(streamId, self.Strength)
	streamWriteInt32(streamId, self.StrengthState)
	streamWriteInt32(streamId, self.DebugState)
end

function loadSettingsForClientEvent:run(connection)
	SlipDestroysFields.SettingsChangedClient(self.Strength, self.StrengthState, self.DebugState)
	if g_server ~= nil then
		g_server:broadcastEvent(loadSettingsForClientEvent.new(self.Strength, self.StrengthState, self.DebugState))
	end
end